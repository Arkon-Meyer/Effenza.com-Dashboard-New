# Effenza Dashboard – Proprietary License

Copyright © 2025 Effenza.com. All rights reserved.

This software and associated documentation files (the “Software”) are the
exclusive property of Effenza.com. The Software may not be copied, modified,
distributed, sublicensed, or used in any form without prior written permission
from Effenza.com.

Use of this Software is restricted to authorized parties under commercial
agreement with Effenza.com.
