# Developer Quickstart

Effenza Dashboard (MVP) — local dev setup.

## Prerequisites
- Node.js 20.x
- npm 9+
- PostgreSQL via pg client

## Install
```bash
git clone https://github.com/effenza/effenza-dashboard.git
cd effenza-dashboard
npm install
